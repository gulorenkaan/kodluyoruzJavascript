
let newName = document.querySelector('#myName');
const promptName = prompt("Please enter your name: ");

newName.innerHTML = promptName;
function updateTime() {
    const now = new Date();
const currentDateTime = now.toLocaleString();
console.log(currentDateTime);

document.querySelector('#myClock').textContent = currentDateTime;
setInterval(updateTime, 1000);}
updateTime();



